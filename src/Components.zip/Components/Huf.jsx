import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    dateofcreation: '',
    deedofhufcreation: '',
    nameofkarta: '',
    aadharofkarta: '',
    bankdetails: '',
    bankname: '',
    membersofkarta: '',
    member1 : '',
    msmeregistration: '',
    msemDoc: null
  });

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;

    if (type === 'file') {
      setFormData({ ...formData, [name]: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }

    setErrors({ ...errors, [name]: '' });
  };

  const validate = () => {
    const newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    
    if (!formData.dateofcreation) newErrors.dateofcreation = 'Required';
    if (!formData.deedofhufcreation || !emailRegex.test(formData.deedofhufcreation)) newErrors.deedofhufcreation = 'Valid deed required';
    if (!formData.nameofkarta || formData.nameofkarta.length < 6) newErrors.nameofkarta = 'Valid deed required'
    if (!formData.aadharofkarta || formData.aadhar.length !== 12) newErrors.aadhar = '12-digit Aadhaar required';
    if (!formData.bankdetails) newErrors.bankdetails = 'Required';
    if (!formData.bankname) newErrors.bankname = 'Required';
    if (!formData.membersofkarta) newErrors.membersofkarta = 'Required';
    if (!formData.member1) newErrors.member1 = 'Required';
    if (formData.msem === 'yes' && !formData.msemDoc) newErrors.msemDoc = 'Upload required';

    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
    } else {
      setSubmitted(true);
      console.log('Form Submitted:', formData);
      // TODO: send to backend or API
    }
  };

  return (
    <div className="container mt-5">
      <div className="card p-4 shadow">
        <h2 className="text-center mb-4">HUF Registration</h2>

        {submitted ? (
          <div className="alert alert-success text-center">Registration Successful!</div>
        ) : (
          <form onSubmit={handleSubmit}>

             {/* Date of Creation  */}
             <div className="mb-3">
              <label className="form-label">Date of Creation</label>
              <input type="date" className={`form-control ${errors.dob && 'is-invalid'}`} name="dob" value={formData.dob} onChange={handleChange} />
              <div className="invalid-feedback">{errors.dob}</div>
            </div>

            {/* Deed of HUF Creation */}
            <div className="mb-3">
              <label className="form-label">Deed of HUF Creation</label>
              <input type="text" className={`form-control ${errors.deedofhufcreation && 'is-invalid'}`} name="deedofhufcreation" value={formData.deedofhufcreation} onChange={handleChange} />
              <div className="invalid-feedback">{errors.deedofhufcreation}</div>
            </div>

            {/* Name of Karta */}
            <div className="mb-3">
              <label className="form-label">Name of Karta</label>
              <input type="email" className={`form-control ${errors.nameofkarta && 'is-invalid'}`} name="nameofkarta" value={formData.email} onChange={handleChange} />
              <div className="invalid-feedback">{errors.deedofhufcreation}</div>
            </div>

             {/* Aadhaar of Karta */}
             <div className="mb-3">
              <label className="form-label">Aadhaar Number</label>
              <input type="text" className={`form-control ${errors.aadhar && 'is-invalid'}`} name="aadhar" value={formData.aadhar} onChange={handleChange} />
              <div className="invalid-feedback">{errors.aadhar}</div>
            </div>

             {/* Bank details */}
             <div className="mb-3">
              <label className="form-label">Bank Details</label>
              <input type="text" className={`form-control ${errors.bankdetails && 'is-invalid'}`} name="bankdetails" value={formData.bankdetails} onChange={handleChange} />
              <div className="invalid-feedback">{errors.bankdetails}</div>
            </div>

            {/* Bank Name */}
            <div className="mb-3">
              <label className="form-label">Bank Details</label>
              <input type="password" className={`form-control ${errors.bankdetails && 'is-invalid'}`} name="bankdetails" value={formData.bankdetails} onChange={handleChange} />
              <div className="invalid-feedback">{errors.bankdetails}</div>
            </div>

            {/* Bank Name */}
            <div className="mb-3">
              <label className="form-label">Bank Name</label>
              <input type="password" className={`form-control ${errors.bankname && 'is-invalid'}`} name="bankname" value={formData.bankname} onChange={handleChange} />
              <div className="invalid-feedback">{errors.bankname}</div>
            </div>

           

            {/* Member of Karta */}
            <div className="mb-3">
              <label className="form-label">Member of Karta</label>
              <input type="text" className={`form-control ${errors.membersofkarta && 'is-invalid'}`} name="membersofkarta" value={formData.membersofkarta} onChange={handleChange} />
              <div className="invalid-feedback">{errors.membersofkarta}</div>
            </div>

            {/* Member1 Pan no. */}
            <div className="mb-3">
              <label className="form-label">Member1 PAN no.</label>
              <input type="text" className={`form-control ${errors.member1 && 'is-invalid'}`} name="members1" value={formData.member1} onChange={handleChange} />
              <div className="invalid-feedback">{errors.member1}</div>
            </div>

            {/* MSEM Registration */}
            <div className="mb-3">
              <label className="form-label">MSEM Registration</label>
              <select className="form-select" name="msem" value={formData.msem} onChange={handleChange}>
                <option value="">-- Select --</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>

            {/* MSEM Upload */}
            {formData.msem === 'yes' && (
              <div className="mb-3">
                <label className="form-label">Upload MSEM Document</label>
                <input type="file" className={`form-control ${errors.msemDoc && 'is-invalid'}`} name="msemDoc" onChange={handleChange} />
                <div className="invalid-feedback">{errors.msemDoc}</div>
              </div>
            )}

            <button type="submit" className="btn btn-primary w-100">Register</button>
          </form>
        )}
      </div>
    </div>
  );
};

export default RegistrationForm;
