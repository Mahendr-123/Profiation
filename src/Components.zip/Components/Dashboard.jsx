const Dashboard = () => (
    <div className="card p-3">
      <h4>📊 Dashboard</h4>
      <p>Welcome to your dashboard!</p>
    </div>
  );
  
  export default Dashboard;
  