import React, { useState } from 'react';

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    DOB: '',
    SEX: '',
    AADHAR: '',
    FATHERS_NAME: '',
    MOTHERS_NAME: '',
    NAME_OF_SPOUSE: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Basic validation or submit logic here
    console.log('Form submitted:', formData);
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card p-4 shadow">
            <h2 className="mb-4 text-center">Registration Form</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="dob" className="form-label">DOB</label>
                <input
                  type="text"
                  className="form-control"
                  id="dob"
                  name="dob"
                  value={formData.DOB}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="email" className="form-label">SEX</label>
                <input
                  type="sex"
                  className="form-control"
                  id="sex"
                  name="sex"
                  value={formData.SEX}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="aadhar" className="form-label">AADHAR</label>
                <input
                  type="aadhar"
                  className="form-control"
                  id="aadhar"
                  name="aadhar"
                  value={formData.AADHAR}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="fathername" className="form-label">Father Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="fathername"
                  name="fathername"
                  value={formData.FATHERS_NAME}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="mothername" className="form-label">Mother Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="mothername"
                  name="mothername"
                  value={formData.MOTHERS_NAME}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="nameofspouse" className="form-label">Name of Spouse</label>
                <input
                  type="text"
                  className="form-control"
                  id="nameofspouse"
                  name="nameofspouse"
                  value={formData.NAME_OF_SPOUSE}
                  onChange={handleChange}
                  required
                />
              </div>
              <button type="submit" className="btn btn-primary w-100">Register</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegistrationForm;
