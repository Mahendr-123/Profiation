const Settings = () => (
    <div className="card p-3">
      <h4>⚙️ Settings</h4>
      <p>Notification: Enabled</p>
      <p>Theme: Dark Mode</p>
    </div>
  );
  
  export default Settings;
  